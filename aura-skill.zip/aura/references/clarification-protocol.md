# Clarification Protocol

Run this BEFORE any design work. Ask one group at a time. Summarize what was decided
after each group before moving to the next. Do not proceed to design until all groups
are answered.

---

## Group 1 — Purpose & Audience

Ask:
- What is the single goal of this page? (one sentence — what should the visitor DO or FEEL?)
- Who is the visitor? Describe them: age range, background, what brought them here,
  what they're hoping to find
- Is there a secondary audience we need to consider?

Wait for answer. Summarize. Ask: "Is this correct before I continue?"

---

## Group 2 — Sections & Content

Ask:
- Walk me through the page top to bottom — what sections do you expect?
- For each section: do you have the actual text/copy, or should I draft it?
- Do you have images/assets, or should I describe what to use as placeholders?
- Is there a CTA (call to action)? What is it? Where should it appear?

Wait for answer. Summarize. Ask: "Have I understood the structure correctly?"

---

## Group 3 — Visual Mood (Opposites Technique)

Present exactly these 5 pairs. The user picks one from each:

```
1. Minimal  ←——→  Rich
2. Cold     ←——→  Warm
3. Playful  ←——→  Serious
4. Light    ←——→  Dark
5. Modern   ←——→  Classic
```

Then ask:
- Do you have any reference sites you like? (even if unrelated industry — just visual feel)
- Any sites you absolutely do NOT want to look like?
- Any brand colors or fonts already defined? If yes, what are they?

Wait for answer. Summarize the mood profile. Ask: "Does this capture your vision?"

---

## Group 4 — Functionality

Ask:
- Any forms on this page? What fields?
- Animations? (scroll reveal, hover, parallax, entrance animations)
- Third-party integrations? (analytics, chat, maps, booking widget, etc.)
- Any specific behavior on mobile that differs from desktop?

Wait for answer. Summarize.

---

## Group 5 — Technical Constraints

Ask:
- What framework/stack? (plain HTML, React, Next.js, Vue, etc.)
- CSS approach? (Tailwind, CSS modules, styled-components, plain CSS)
- Are there existing components or a design system to reuse?
- Any performance requirements? (e.g., "must score 90+ on Lighthouse")
- Accessibility requirements? (WCAG AA minimum is always the default)

Wait for answer. Summarize.

---

## Final Summary

Before starting Phase 2 (Reasoning), produce a complete Page Brief using the
template in `references/page-brief-template.md`, filled with everything learned
from this protocol.

Show it to the user and say: "This is my complete understanding of the brief.
If anything is wrong or missing, tell me now before I start designing."
