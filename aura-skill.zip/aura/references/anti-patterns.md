# Anti-Patterns — What Aura Never Does

These are design mistakes Aura actively prevents. When a user brief implies one of these,
flag it, explain why it's a problem, and propose an alternative before building.

---

## Visual Anti-Patterns

**Dark overlay + white text on photos**
Problem: Destroys the photo, reduces contrast unpredictably, looks dated.
Alternative: Use a solid color section instead, or position text beside the image, or use
a frosted glass card, or choose a photo that has a naturally clear area for text.

**Gradient backgrounds as the primary design element**
Problem: Trends age fast; gradients that look modern today look cheap in 2 years.
Alternative: Use flat color. If you need variation, use subtle texture or a two-tone
layout with a hard edge.

**Stock photo aesthetics**
Problem: Businesspeople shaking hands, diverse teams laughing at laptops, generic
product-on-white — these signal low effort and damage trust.
Alternative: Use abstract geometry, real product screenshots, icons, illustrations, or
properly art-directed photography.

**Centering everything**
Problem: Center-aligned text is hard to read for more than 2 lines. It also creates weak
left edges making scanning harder.
Alternative: Left-align body text always. Center only short headlines (max 10 words),
hero headlines, or isolated CTA sections.

**Too many font sizes on one page**
Problem: More than 4–5 distinct text sizes creates visual noise, not hierarchy.
Alternative: Define a strict type scale (H1, H2, H3, body, caption, label) and stick to it.

**Thin fonts on dark backgrounds**
Problem: Light/thin fonts on dark surfaces lose readability and feel airy in the wrong way.
Alternative: Use regular or medium weight on dark backgrounds. Reserve thin weights for
large display text on light backgrounds only.

**Borders everywhere**
Problem: Using borders to separate every element is the CSS equivalent of "I don't know
how to use whitespace."
Alternative: Use whitespace and background color variation to separate sections. Reserve
borders for tables, inputs, and intentional card outlines.

---

## UX Anti-Patterns

**Auto-playing media (video, audio, carousels)**
Problem: Takes away user control; carousels are consistently shown to have near-zero
engagement on slides beyond the first.
Alternative: Use a static hero with a play button for video. Replace carousels with a
visible grid of items or a scroll-based reveal.

**Infinite scroll without exit**
Problem: Users can't find their place, can't share a position, and feel trapped.
Alternative: Pagination for content that needs to be navigated, load-more button for feeds.

**Forms with no inline validation**
Problem: Submitting and then seeing all errors at once is frustrating. Mobile users lose
context scrolling up to fix fields.
Alternative: Validate on blur (when user leaves a field) and show inline success/error states.

**Disabled buttons with no explanation**
Problem: User sees a button they can't click with no feedback about why.
Alternative: Either show the button as active and validate on click with an error message,
or show a tooltip on hover/focus explaining what's needed to enable it.

**Hamburger menus on desktop**
Problem: Hides navigation behind an extra click on a device that has plenty of space.
Alternative: Visible navigation bar on desktop. Hamburger is fine on mobile only.

**Links that look like buttons and buttons that look like links**
Problem: Breaks user mental model of affordances.
Alternative: Buttons trigger actions (submit, open modal, expand). Links navigate to URLs.
Keep them visually distinct always.

---

## Performance Anti-Patterns

**Full-width unoptimized hero images**
Problem: A 4MB JPEG in the hero destroys first paint performance.
Alternative: Use WebP, serve responsive sizes with srcset, lazy-load everything below the fold.

**Loading all fonts upfront**
Problem: Google Fonts with 10 weights blocks rendering.
Alternative: Load only the weights you use. Use `font-display: swap`. Prefer variable fonts.

**Animation on every scroll**
Problem: Scroll-triggered animations on every element cause layout thrashing and feel
gimmicky.
Alternative: Animate maximum 1–2 elements per section. Prefer subtle fade/slide. Always
respect `prefers-reduced-motion`.

---

## Copy Anti-Patterns (UX Copywriting)

**"Welcome to our website"**
Alternative: Start with the user's problem or the benefit they'll get.

**Feature-first headlines** ("Powered by AI", "Built for scale")
Alternative: Benefit-first headlines ("Ship faster. Sleep better.", "Your data, always private.")

**Vague CTAs** ("Learn more", "Click here", "Submit")
Alternative: Action-specific CTAs ("Start free trial", "See pricing", "Download the guide")

**Form labels as placeholder text only**
Problem: Label disappears when the user types. User forgets what the field is for.
Alternative: Always use real labels above or beside the input.
