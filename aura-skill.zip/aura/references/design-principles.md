# Design Principles

These are the rules Aura applies to every project. They are not suggestions.
If a client brief conflicts with a principle, explain why and propose a solution
that satisfies both the client goal and the principle.

---

## Composition

**F-pattern and Z-pattern reading**
- Long-form content (articles, docs): design for F-pattern — left-aligned, scannable
- Landing pages and marketing: design for Z-pattern — diagonal eye movement
- Never place key information in the bottom-right of a Z-pattern section

**Visual weight balance**
- Every layout must have a clear dominant element (largest visual weight)
- Supporting elements decrease in size/weight progressively
- If two elements have equal visual weight, one must be adjusted

**Breathing room (negative space)**
- Sections need vertical padding: minimum 80px top/bottom on desktop, 48px on mobile
- Give headings room to breathe above them (at least 1.5× the font size)
- Cards and grouped elements need consistent internal padding (16px or 24px)

---

## Typography in Practice

**Heading hierarchy**
- H1: 48–80px (hero) or 32–48px (section headings)
- H2: 24–36px
- H3: 18–24px
- Body: 16–18px
- Caption/label: 12–14px

**Text width for readability**
- Body text: 60–75 characters per line (roughly 600–700px at 16px)
- Never stretch body text full-width on large screens

**Uppercase text**
- Use sparingly: labels, navigation items, small tags only
- Never use all-caps for body text or headings longer than 5 words
- Add letter-spacing of 0.05–0.1em when using uppercase

---

## Color in Practice

**60-30-10 rule**
- 60% dominant color (usually background)
- 30% secondary color (sections, cards, UI elements)
- 10% accent color (CTAs, highlights, focus states)

**When to use dark mode**
- Only if the product is used in low-light environments (developer tools, monitoring dashboards)
- Don't default to dark just because it looks "cool" without audience justification

**Color psychology quick reference**
- Blue: trust, stability, technology → B2B SaaS, finance, health
- Green: growth, nature, success → fintech, sustainability, wellness
- Orange/yellow: energy, optimism → consumer apps, food, education
- Purple: creativity, luxury, mystery → beauty, creative tools, premium
- Black/white: sophistication, simplicity → premium brands, portfolios
- Red: urgency, passion, alert → use sparingly, mostly for errors and warnings

---

## Responsive Design

**Breakpoints (use these exactly)**
- Mobile: 375px (design target), support 320px minimum
- Tablet: 768px
- Desktop: 1280px (design target), support up to 1920px
- Wide: 1440px+ (use max-width container, not full-bleed content)

**Mobile-first rules**
- Start with mobile layout, add complexity for larger screens
- Touch targets: minimum 44×44px for any interactive element
- Font sizes never below 14px on mobile (16px for body)
- No hover-only interactions — every hover state needs a tap-equivalent

---

## Accessibility (Non-Negotiable)

- WCAG AA minimum on every project: 4.5:1 for text, 3:1 for large text and UI
- Focus states must be visible (never `outline: none` without a replacement)
- Images need alt text (decorative images get `alt=""`)
- Forms need labels (not just placeholder text)
- Color alone must never convey information (add icon or text)
- Semantic HTML: use h1-h6 in order, use button for buttons, link for navigation
