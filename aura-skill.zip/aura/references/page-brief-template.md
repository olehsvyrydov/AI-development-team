# Page Brief Template

Use this template to document the full brief before any design work begins.
Fill every field — write "TBD" only if the user explicitly says they don't know yet.
Present the completed brief to the user for approval before starting Phase 2.

---

## Page Brief: [PAGE NAME]

**Project:** [project/product name]
**Date:** [date]
**Stack:** [framework + CSS approach]

---

### 1. Purpose

- **Primary goal:** [What should the visitor DO after seeing this page?]
- **Secondary goal:** [Optional secondary action or feeling]
- **Success metric:** [How will you know this page is working? e.g., "10% CTA click rate"]

---

### 2. Audience

- **Primary user:** [Description: who they are, what brought them here, their emotional state]
- **Secondary user:** [If applicable]
- **What they fear:** [What concern or doubt do they arrive with?]
- **What they hope:** [What are they looking for?]

---

### 3. Structure (sections top to bottom)

| # | Section name | Content | CTA |
|---|---|---|---|
| 1 | Hero | [describe] | [button label → destination] |
| 2 | [name] | [describe] | [if any] |
| 3 | [name] | [describe] | [if any] |
| … | … | … | … |

---

### 4. Visual Mood Profile

| Axis | Choice |
|---|---|
| Minimal ←→ Rich | [choice] |
| Cold ←→ Warm | [choice] |
| Playful ←→ Serious | [choice] |
| Light ←→ Dark | [choice] |
| Modern ←→ Classic | [choice] |

- **Reference sites (like):** [URLs or descriptions]
- **Reference sites (dislike):** [URLs or descriptions]
- **Brand colors:** [hex values or "none defined"]
- **Brand fonts:** [font names or "none defined"]

---

### 5. Color Palette

| Role | Color | Hex |
|---|---|---|
| Primary | | |
| Secondary | | |
| Accent | | |
| Background | | |
| Surface | | |
| Text | | |
| Muted text | | |

---

### 6. Typography

| Role | Font | Weight | Size (desktop) |
|---|---|---|---|
| Display/H1 | | | |
| H2 | | | |
| H3 | | | |
| Body | | | |
| Caption | | | |

---

### 7. Functionality

- **Forms:** [fields, validation rules, success behavior]
- **Animations:** [which elements, type of animation, trigger]
- **Third-party integrations:** [list]
- **Mobile-specific behavior:** [any differences from desktop]

---

### 8. Technical Constraints

- **Framework:** [React / Next.js / Vue / plain HTML / etc.]
- **CSS approach:** [Tailwind / CSS modules / styled-components / plain CSS]
- **Existing components to reuse:** [list or "none"]
- **Performance target:** [Lighthouse score or "WCAG AA minimum"]
- **Browser support:** [modern browsers / IE11 / etc.]

---

### 9. Anti-Patterns to Avoid (this project)

[List any specific things the user said they don't want — extracted from clarification]

---

### 10. Success Criteria

This page is done when:
1. [Specific, measurable condition]
2. [Specific, measurable condition]
3. [Specific, measurable condition]
4. [Specific, measurable condition]
5. Passes WCAG AA contrast check on all text elements
6. Renders correctly at 375px and 1440px without horizontal scroll
