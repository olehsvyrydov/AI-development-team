# Color System — Semantic Token Naming

Use this naming convention for all design tokens. Consistent naming makes it easy
to switch themes, support dark mode, and hand off to developers.

---

## Token Structure

```
--color-{role}-{variant?}-{state?}
```

Examples:
- `--color-primary` — main brand color
- `--color-primary-light` — lighter tint
- `--color-primary-dark` — darker shade
- `--color-text-muted` — secondary text
- `--color-bg-surface` — card/panel background

---

## Required Semantic Tokens

### Brand
```css
--color-primary        /* main brand color — use for CTAs, active states, links */
--color-primary-light  /* 20% lighter tint — hover backgrounds, badges */
--color-primary-dark   /* 20% darker shade — pressed states, active buttons */
--color-secondary      /* supporting brand color — secondary CTAs, accents */
--color-accent         /* highlight color — use sparingly for emphasis only */
```

### Backgrounds
```css
--color-bg-base        /* page background */
--color-bg-surface     /* card, panel, modal background */
--color-bg-subtle      /* very light tint for section alternation */
--color-bg-overlay     /* semi-transparent overlay for modals */
```

### Text
```css
--color-text-primary   /* main body text — must be 4.5:1 on bg-base */
--color-text-secondary /* supporting text — 4.5:1 on bg-base */
--color-text-muted     /* captions, labels — 3:1 on bg-base minimum */
--color-text-disabled  /* disabled state text */
--color-text-inverse   /* text on dark/primary backgrounds */
--color-text-link      /* hyperlink color — must be distinguishable without underline */
```

### Borders
```css
--color-border-default /* subtle dividers, card borders */
--color-border-strong  /* form inputs, visible separators */
--color-border-focus   /* focus ring — must be visible against bg-base */
```

### Feedback
```css
--color-success        /* positive states, success messages */
--color-success-bg     /* success message background */
--color-warning        /* warning states */
--color-warning-bg     /* warning message background */
--color-error          /* error states, destructive actions */
--color-error-bg       /* error message background */
--color-info           /* informational states */
--color-info-bg        /* informational message background */
```

---

## Example: Minimal Palette Implementation

```css
:root {
  /* Brand */
  --color-primary:        #2563EB;  /* blue-600 */
  --color-primary-light:  #EFF6FF;  /* blue-50 */
  --color-primary-dark:   #1D4ED8;  /* blue-700 */
  --color-secondary:      #7C3AED;  /* violet-600 */
  --color-accent:         #F59E0B;  /* amber-500 */

  /* Backgrounds */
  --color-bg-base:        #FFFFFF;
  --color-bg-surface:     #F9FAFB;  /* gray-50 */
  --color-bg-subtle:      #F3F4F6;  /* gray-100 */
  --color-bg-overlay:     rgba(0, 0, 0, 0.5);

  /* Text */
  --color-text-primary:   #111827;  /* gray-900 */
  --color-text-secondary: #374151;  /* gray-700 */
  --color-text-muted:     #6B7280;  /* gray-500 */
  --color-text-disabled:  #9CA3AF;  /* gray-400 */
  --color-text-inverse:   #FFFFFF;
  --color-text-link:      #2563EB;  /* matches primary */

  /* Borders */
  --color-border-default: #E5E7EB;  /* gray-200 */
  --color-border-strong:  #D1D5DB;  /* gray-300 */
  --color-border-focus:   #2563EB;  /* matches primary */

  /* Feedback */
  --color-success:        #16A34A;  /* green-600 */
  --color-success-bg:     #F0FDF4;  /* green-50 */
  --color-warning:        #D97706;  /* amber-600 */
  --color-warning-bg:     #FFFBEB;  /* amber-50 */
  --color-error:          #DC2626;  /* red-600 */
  --color-error-bg:       #FEF2F2;  /* red-50 */
  --color-info:           #0284C7;  /* sky-600 */
  --color-info-bg:        #F0F9FF;  /* sky-50 */
}
```

---

## Contrast Check Quick Reference

| Text size | Minimum ratio | AA | AAA |
|---|---|---|---|
| Body text (< 18px regular) | 4.5:1 | ✓ | 7:1 |
| Large text (≥ 18px regular or ≥ 14px bold) | 3:1 | ✓ | 4.5:1 |
| UI components, icons | 3:1 | ✓ | — |

Use https://webaim.org/resources/contrastchecker/ to verify.

---

## Tailwind CSS Mapping

If using Tailwind, document which Tailwind color tokens map to semantic roles:

```js
// tailwind.config.js
theme: {
  extend: {
    colors: {
      primary: {
        DEFAULT: '#2563EB',
        light: '#EFF6FF',
        dark: '#1D4ED8',
      },
      // ... etc
    }
  }
}
```
